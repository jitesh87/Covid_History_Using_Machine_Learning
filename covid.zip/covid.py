#question:-1
#a(i)
import pandas as pd
data=pd.read_csv(r"C:\Users\91889\Downloads\public-covid-19-cases-canada.csv")
data.head()
data.shape
data.describe()
data.info()


#a(ii)
data.isnull()
(data.isnull()).sum()
data['sex'].value_counts()
data['age'].value_counts()


#a(iii)
##Two insights are:-
##1)More than 90%people not reported their age and genger
##2)has_travel_history(49832),locally_acquired(50408) has null


#b(i)
##dropped first unwanted column
data1=df=data.drop('case_id',1)
data1.shape
##dropped all null values
data2=data1.dropna()
data2.shape
data2['sex'].value_counts()
data2['age'].value_counts()
##dropped all not reported
data2=data2[data2['sex']!='Not Reported']
data2=data2[data2['age']!='Not Reported']
data2['age'].value_counts()


#b(ii)
##reformated the age group
data2['age']=data2['age'].replace('<20','0-19')
data2['age']=data2['age'].replace('10-19','0-19')
data2['age']=data2['age'].replace('<10','0-19')
data2['age']=data2['age'].replace('<18','0-19')
data2['age']=data2['age'].replace('<1','0-19')
data2['age'].value_counts()


#b(iii)
a=data2.groupby('age').count()
print(a['sex'])


#c
##Save the cleaned and reformatted dataset into a new covid_edit.csv file.
data2.to_csv('covid_edit.csv')


#question:-2
#b(i)
import pandas as pd
data2=pd.read_csv(r"C:\Users\91889\OneDrive\Desktop\python\covid_edit.csv")
#reformating the data
data2["DATE"]=pd.to_datetime(data2['date_report'])
#total number of infectors in month 2
a=data2[data2['DATE'].dt.month==2]
print(a['sex'].value_counts())
#total number of infectors in month 3
b=data2[data2['DATE'].dt.month==3]
print(b['sex'].value_counts())
#total number of infectors in month 4
c=data2[data2['DATE'].dt.month==4]
print(c['sex'].value_counts())


#b(ii)
#sorted female infectors in descending order
w=data2[data2['sex']=="Female"]
print(w.groupby('age').size().sort_values(ascending=False))


#b(iii)
a=data2[data2['DATE'].dt.month==2]
a1=a[(a['has_travel_history']=='f')  & (a['age']=='50-59') | (a['age']=='60-69') | (a['age']=='70-79') | (a['age']=='80-89') | (a['age']=='90-99')].count()
b=data2[data2['DATE'].dt.month==3]
b1=b[(b['has_travel_history']=='f')  & (b['age']=='50-59') | (b['age']=='60-69') | (b['age']=='70-79') | (b['age']=='80-89') | (b['age']=='90-99')].count()
c=data2[data2['DATE'].dt.month==4]
c1=c[(c['has_travel_history']=='f')  & (c['age']=='50-59') | (c['age']=='60-69') | (c['age']=='70-79') | (c['age']=='80-89') | (c['age']=='90-99')].count()
##The top Two months with number of infectors older than 50 is
## 1)month 4 (129 infectors)
## 2)month 3 (99 infectors)


#question:-3
#a
#Q3(a) is same in Q2(b)


#b(i)
#function that prints the Top THREE provinces
def function(q):
    x=q.groupby('province').size().sort_values(ascending=False)
    print(x.head(3))
#calling the function with regards of  2nd month
a=data2[data2['DATE'].dt.month==2]
function(a)
#calling the function with regards of 3rd month
b=data2[data2['DATE'].dt.month==3]
function(b)
#calling the function with regards of 4th month
c=data2[data2['DATE'].dt.month==4]
function(c)


#b(ii)
#Bar graph to show the total number of covid-19 cases for each province
import matplotlib.pyplot as plt
dic={}
for i in data2['province']:
    if i not in dic:
        dic[i]=1
    else:
        dic[i]+=1
values=list(dic.values())
province=list(dic.keys())
plt.bar(province,values,color="blue",width=0.4)
plt.xlabel("province")
plt.ylabel("No. of COVID-19 cases")
plt.title("Total number of covid-19 cases for each province")
plt.show()


#b(iii)
#Ontario has the highest number of cases
w=data2[data2['province']=='Ontario']
male=[]
female=[]

w1=w[(w['age']=='0-19')]
male.append((w1[w1['sex']=='Male'].count())['age'])
female.append((w1[w1['sex']=='Female'].count())['age'])

w1=w[(w['age']=='20-29')]
male.append((w1[w1['sex']=='Male'].count())['age'])
female.append((w1[w1['sex']=='Female'].count())['age'])

w1=w[(w['age']=='30-39')]
male.append((w1[w1['sex']=='Male'].count())['age'])
female.append((w1[w1['sex']=='Female'].count())['age'])

w1=w[(w['age']=='40-49')]
male.append((w1[w1['sex']=='Male'].count())['age'])
female.append((w1[w1['sex']=='Female'].count())['age'])

w1=w[(w['age']=='50-59')]
male.append((w1[w1['sex']=='Male'].count())['age'])
female.append((w1[w1['sex']=='Female'].count())['age'])

w1=w[(w['age']=='60-69')]
male.append((w1[w1['sex']=='Male'].count())['age'])
female.append((w1[w1['sex']=='Female'].count())['age'])

w1=w[(w['age']=='70-79')]
male.append((w1[w1['sex']=='Male'].count())['age'])
female.append((w1[w1['sex']=='Female'].count())['age'])

w1=w[(w['age']=='80-89')]
male.append((w1[w1['sex']=='Male'].count())['age'])
female.append((w1[w1['sex']=='Female'].count())['age'])

w1=w[(w['age']=='90-99')]
male.append((w1[w1['sex']=='Male'].count())['age'])
female.append((w1[w1['sex']=='Female'].count())['age'])

#Bar graph of Ontario to show the total number of covid-19 cases per gender by age distribution
import matplotlib.pyplot as plt
w=0.4
x=["0-19","20-29","30-39","40-49","50-59","60-69","70-79","80-89","90-99"]
plt.bar(x,male,w,label="Male")
plt.bar(x,female,w,bottom=male,label="Female")
plt.xlabel("Age distribution")
plt.ylabel("No. of COVID-19 cases")
plt.title("Total number of covid-19 cases per gender by age distribution(Ontario)")
plt.legend()
plt.show()


#c(i)
import pandas as pd
def function(date):
    date=pd.to_datetime(date)
    return date.day_name()
q=[]
for i in data2['report_week']:
    q.append(function(i))
data2['report_week'].update(q)
print(data2['report_week'])


#c(ii) 
#The top three days that covid-19 cases detected
a=data2['DATE'].value_counts()
print(a.head(3))
##2020-03-26    63
##2020-03-25    26
##2020-04-27    24


#c(iii)
def diction(n):
    dic={}
    for i in n:
        if i not in dic:
            dic[i]=1
        else:
            dic[i]+=1
    return dic
data2["DATE"]=pd.to_datetime(data2['date_report'])
#total number of infectors in month 2
a=data2[data2['DATE'].dt.month==2]
m2=diction(a['sex'])
#total number of infectors in month 3
b=data2[data2['DATE'].dt.month==3]
m3=diction(b['sex'])
#total number of infectors in month 4
c=data2[data2['DATE'].dt.month==4]
m4=diction(c['sex'])
#Bar graph to show the total number of covid-19 cases per gender for each month
import matplotlib.pyplot as plt
w=0.4
x=["feb","mar","apr"]
male=[m2['Male'],m3['Male'],m4['Male']]
female=[m2['Female'],m3['Female'],m4['Female']]
plt.bar(x,male,w,label="Male")
plt.bar(x,female,w,bottom=male,label="Female")
plt.xlabel("Months")
plt.ylabel("No. of COVID-19 cases")
plt.title("Total number of covid-19 cases for each month")
plt.legend()
plt.show()






    





